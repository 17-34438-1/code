var express = require('express');
var userModel = require.main.require('./model/user-model');
var Model= require.main.require('./model/book');
var router = express.Router();


//ROUTES
router.get('*', function(req, res, next){
	if(req.session.un != null){
		next();
	}else{
		res.redirect('/login1');
	}
});

router.get('/', function(req, res){
	
	userModel.getAll(function(results){
		var data = {
			name: req.session.un,
			uList: results
		};
		res.render('home1/indexx', data);
	});
});

router.get('/profile1', function(req, res){

	userModel.get(req.session.uid, function(result){

		if(result != ""){
			res.render('home1/profile1', result);
		}else{
			res.redirect('/home1');
		}
	});
});
router.get('/search1', function(req, res){

	Model.search1(req.params.key, function(results){
	
		res.render('home1/search1');
	});
});


router.get('/search1/:key', function(req, res){

	Model.search1(req.params.key, function(results){

		res.send(results);
	});
});
module.exports = router;






